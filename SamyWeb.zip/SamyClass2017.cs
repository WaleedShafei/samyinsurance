﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SamyWeb
{
    public class SamyClass2017
    {
        public static int VarChoice = 0;
        public static int ws_inspriod9 = 0;
        public static Double ws_pos = 0, ws_hel = 0, ws_dep = 0, ws_acc = 0, ws_pen = 0;
        public static Double ws_pos2 = 0, ws_hel2 = 0, ws_dep2 = 0, ws_acc2 = 0, ws_pen2 = 0;
        public static Double pos = 0, hel = 0, dep = 0, acc = 0, pen = 0, ws_mont = 0;
        public static Double pos2 = 0, hel2 = 0, dep2 = 0, acc2 = 0, pen2 = 0;
        public static string passnam = "", user = "";
        public static int w_tr = 0, ws_cur = 0, pascod = 0, ww = 0;
        public static Double w_kst = 0, w_prem = 0, w_kstyer = 0, w_nbs1 = 0, w_esh1 = 0;
        public static Double w_nbs2 = 0, w_esh2 = 0, w_nbs3 = 0, w_esh3 = 0;
        public static Double w_nbs16 = 0, w_esh16 = 0, w_nbs26 = 0, w_esh26 = 0;
        public static Double w_nbs36 = 0, w_esh36 = 0, w_nbs46 = 0, w_esh46 = 0;
        public static Double w_nbs56 = 0, w_esh56 = 0;
        public static Double w_nbs4 = 0, w_esh4 = 0, w_nbs5 = 0, w_esh5 = 0;
        public static Double o_o1111 = 0, o_o2222 = 0, o_o3333 = 0, o_o4444 = 0, o_o5555 = 0;
        public static Double o_o111 = 0, o_o222 = 0, o_o333 = 0, o_o444 = 0, o_o555 = 0;
        public static Double o_o11 = 0, o_o22 = 0, o_o33 = 0, o_o44 = 0, o_o55 = 0;
        public static Double o_o1 = 0, o_o2 = 0, o_o3 = 0, o_o4 = 0, o_o5 = 0;
        public static Double o_oz = 0, o_ozz = 0, o_ozzz = 0, o_ozzzz = 0;

        public static Decimal qq_numall = 0, qq_numall2 = 0, qq_numall3 = 0, ws_ser = 0;
        public static DateTime qq_strd = Convert.ToDateTime("1900/01/01");
        public static String qq_nam = "", qq_nam2 = "", qq_adr = "", qq_life = "";
        public static String qq_nam3 = "", qq_pos3 = "", qq_adr3 = "";
        public static String qq_deth = "", qq_amil = "", qq_fax = "";
        public static String qq_phon = "", qq_phon2 = "", ww_sam = "", ww_mos = "";
        public static String qq_pos = "", qq_pos2 = "", qq_adr2 = "";
        public static Decimal qq_rkm = 0;
        public static int z_dx = 0, z_dxx = 0, z_dxxx = 0;
        public static Double w_omola1 = 0, w_omola2 = 0, w_omola3 = 0, w_omola4 = 0;
        public static Double w_omola5 = 0, w_30 = 0, w_10 = 0, n_om3 = 0, w3 = 0;
        public static Double n_om4 = 0, n_om5 = 0, w_5 = 0, w_60 = 0;
        public static Double w_omola_all = 0, w_omola0 = 0, w_omolat = 0, adm1 = 0;
        public static Double adm2 = 0, w4 = 0, w5 = 0, wall = 0;
        public static Double ws_kst1 = 0, ws_kst2 = 0, ws_kst3 = 0, ws_kst4 = 0;
        public static Double ws_kst16 = 0, ws_kst26 = 0, ws_kst36 = 0, ws_kst46 = 0, ws_kst56 = 0;
        public static Double w_rkm = 0, ws_kst5 = 0;
        public static int ws_cod = 0, ws_inspriod = 0, ws_mab = 0, ws_mab99 = 0;
        public static int ws_sen1 = 0, ws_sen2 = 0, ws_sendiv = 0, sen = 0;
        public static int ws_sdadtyp = 0, z_tsts = 0;
        public static int xmodasdd = 0, ws_dentyp = 0;
        public static int ww_payednow = 0, idomola = 0, w_prod = 0;
        public static Double ww_kstnt = 0.0, ww_kst3 = 0.0, z_auts = 0;
        public static double w_kstall = 0.0, w_nsb = 0.0, w_esh = 0.0;
        public static Double z_kstyer_all = 0, rkm = 0, w_dival = 0;
        public static Double n_kst = 0, ws_denkst = 0.0, kstpayed = 0.0;
        public static Double n_om0 = 0.0, n_om1 = 0.0, n_om2 = 0.0, z_rat_one = 0;
        public static Double z_asr_val = 0, z_adds = 0, z_deds = 0;
        public static DateTime datnul = Convert.ToDateTime("1900/01/01");
        public static DateTime wdat1 = Convert.ToDateTime("1900/01/01");
        public static DateTime wdat2 = Convert.ToDateTime("1900/01/01");
        public static DateTime z_dat2 = Convert.ToDateTime("1900/01/01");
        public static DateTime ws_strd = Convert.ToDateTime("1900/01/01");
        public static DateTime a1900 = Convert.ToDateTime("1900/01/01");
        public static DateTime ws_endd = Convert.ToDateTime("1900/01/01");
        public static DateTime ws_brth = Convert.ToDateTime("1900/01/01");
        public static DateTime ws_brth2 = Convert.ToDateTime("1900/01/01");

        /// <summary>
        /// ///
        /// </summary>
        public static DateTime strdValue = Convert.ToDateTime("1900/01/01");
        public static DateTime datetst = Convert.ToDateTime("2017/01/01");
        public static DateTime tday = Convert.ToDateTime("1900/01/01");

        public static double ryer = 0, rhav = 0, rqrt = 0, rmonth = 0, ronly = 0;

        public static double dx = 0, nx = 0, sx = 0, mx = 0, rx = 0;
        public static double dx1 = 0, nx1 = 0, sx1 = 0, mx1 = 0, rx1 = 0;
        public static double dx2 = 0, nx2 = 0, sx2 = 0, mx2 = 0, rx2 = 0;
        public static double dx3 = 0, nx3 = 0, sx3 = 0, mx3 = 0, rx3 = 0;
        public static double dx4 = 0, nx4 = 0, sx4 = 0, mx4 = 0, rx4 = 0;
        public static double dx10 = 0, nx10 = 0, sx10 = 0, mx10 = 0, rx10 = 0;




        public static int para1 = 0, para2 = 0, para3 = 0;
    }

}